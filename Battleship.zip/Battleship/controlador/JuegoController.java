package controlador;

import modelo.Tablero;
import vista.Consola;
import ia.IAJugador;
import java.util.Scanner;

public class JuegoController {
    private Tablero jugador;
    private Tablero ia;
    private Consola vista;
    private IAJugador iaJugador;
    private Scanner scanner;

    public JuegoController() {
        jugador = new Tablero(10);
        ia = new Tablero(10);
        vista = new Consola();
        iaJugador = new IAJugador(10);
        scanner = new Scanner(System.in);
    }

    public void iniciarJuego() {
        jugador.colocarFlota();
        ia.colocarFlota();

        while (true) {
            vista.mostrarTablero(ia, true);
            vista.mensaje("Tu turno. Ingresa coordenadas (ej. A5): ");
            String entrada = scanner.nextLine().toUpperCase();

            if (entrada.length() < 2) continue;

            int col = entrada.charAt(0) - 'A';
            int fila = Character.getNumericValue(entrada.charAt(1));

            if (fila < 0 || fila >= 10 || col < 0 || col >= 10 || ia.yaDisparado(fila, col)) {
                vista.mensaje("Coordenadas inválidas o ya usadas.");
                continue;
            }

            boolean impacto = ia.disparar(fila, col);
            vista.mensaje(impacto ? "¡Impacto!" : "Agua...");

            if (ia.flotaHundida()) {
                vista.mensaje("¡Ganaste! Hundiste toda la flota enemiga.");
                break;
            }

            // Turno IA
            int[] coords = iaJugador.obtenerCoordenadas();
            boolean impactoIA = jugador.disparar(coords[0], coords[1]);
            vista.mensaje("IA disparó a " + coords[0] + "," + coords[1] + ": " + (impactoIA ? "¡Impacto!" : "Agua..."));

            if (jugador.flotaHundida()) {
                vista.mensaje("¡Perdiste! La IA hundió toda tu flota.");
                break;
            }
        }
    }
}
