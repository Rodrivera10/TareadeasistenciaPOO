import controlador.JuegoController;

public class Main {
    public static void main(String[] args) {
        JuegoController juego = new JuegoController();
        juego.iniciarJuego();
    }
}
