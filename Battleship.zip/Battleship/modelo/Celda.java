package modelo;

public class Celda {
    private boolean fueDisparada;
    private Barco barco;

    public Celda() {
        this.fueDisparada = false;
        this.barco = null;
    }

    public boolean tieneBarco() {
        return barco != null;
    }

    public void colocarBarco(Barco barco) {
        this.barco = barco;
    }

    public boolean disparar() {
        fueDisparada = true;
        if (barco != null) {
            barco.recibirImpacto();
            return true;
        }
        return false;
    }

    public boolean fueDisparada() {
        return fueDisparada;
    }

    public Barco getBarco() {
        return barco;
    }
}
