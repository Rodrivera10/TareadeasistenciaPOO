package modelo;

public class Barco {
    private int tamaño;
    private int impactos;

    public Barco(int tamaño) {
        this.tamaño = tamaño;
        this.impactos = 0;
    }

    public void recibirImpacto() {
        impactos++;
    }

    public boolean estaHundido() {
        return impactos >= tamaño;
    }

    public int getTamaño() {
        return tamaño;
    }
}
