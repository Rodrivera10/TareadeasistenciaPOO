package modelo;

import java.util.Random;

public class Tablero {
    private Celda[][] celdas;
    private int tamaño;
    private Barco[] flota;

    public Tablero(int tamaño) {
        this.tamaño = tamaño;
        celdas = new Celda[tamaño][tamaño];
        for (int i = 0; i < tamaño; i++)
            for (int j = 0; j < tamaño; j++)
                celdas[i][j] = new Celda();
    }

    public void colocarFlota() {
        flota = new Barco[] {
            new Barco(2), new Barco(3), new Barco(4), new Barco(5)
        };
        Random rand = new Random();

        for (Barco barco : flota) {
            boolean colocado = false;
            while (!colocado) {
                int fila = rand.nextInt(tamaño);
                int col = rand.nextInt(tamaño);
                boolean horizontal = rand.nextBoolean();

                if (puedeColocar(barco.getTamaño(), fila, col, horizontal)) {
                    for (int i = 0; i < barco.getTamaño(); i++) {
                        int f = fila + (horizontal ? 0 : i);
                        int c = col + (horizontal ? i : 0);
                        celdas[f][c].colocarBarco(barco);
                    }
                    colocado = true;
                }
            }
        }
    }

    private boolean puedeColocar(int tamañoBarco, int fila, int col, boolean horizontal) {
        if (horizontal && col + tamañoBarco > tamaño) return false;
        if (!horizontal && fila + tamañoBarco > tamaño) return false;

        for (int i = 0; i < tamañoBarco; i++) {
            int f = fila + (horizontal ? 0 : i);
            int c = col + (horizontal ? i : 0);
            if (celdas[f][c].tieneBarco()) return false;
        }
        return true;
    }

    public boolean disparar(int fila, int col) {
        return celdas[fila][col].disparar();
    }

    public boolean yaDisparado(int fila, int col) {
        return celdas[fila][col].fueDisparada();
    }

    public boolean flotaHundida() {
        for (Barco barco : flota)
            if (!barco.estaHundido()) return false;
        return true;
    }

    public Celda[][] getCeldas() {
        return celdas;
    }
}
