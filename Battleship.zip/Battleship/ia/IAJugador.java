package ia;

import java.util.*;

public class IAJugador {
    private Set<String> disparosRealizados = new HashSet<>();
    private Random random = new Random();
    private int tamañoTablero;

    public IAJugador(int tamañoTablero) {
        this.tamañoTablero = tamañoTablero;
    }

    public int[] obtenerCoordenadas() {
        int fila, columna;
        String clave;

        do {
            fila = random.nextInt(tamañoTablero);
            columna = random.nextInt(tamañoTablero);
            clave = fila + "," + columna;
        } while (disparosRealizados.contains(clave));

        disparosRealizados.add(clave);
        return new int[]{fila, columna};
    }
}
