package vista;

import modelo.Tablero;

public class Consola {
    public void mostrarTablero(Tablero tablero, boolean ocultarBarcos) {
        System.out.println("  A B C D E F G H I J");
        for (int i = 0; i < 10; i++) {
            System.out.print(i + " ");
            for (int j = 0; j < 10; j++) {
                var celda = tablero.getCeldas()[i][j];
                if (celda.fueDisparada()) {
                    System.out.print(celda.tieneBarco() ? "X " : "O ");
                } else {
                    System.out.print(ocultarBarcos ? "~ " : (celda.tieneBarco() ? "B " : "~ "));
                }
            }
            System.out.println();
        }
    }

    public void mensaje(String msg) {
        System.out.println(msg);
    }
}
